module.exports = {
    mongoURI :"mongodb://localhost:27017/LinkedinPrototypeDatabase"
}


//mongodb+srv://psjc:psjc@linkedinprototype-h02vm.mongodb.net/test?retryWrites=true