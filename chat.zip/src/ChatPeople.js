import React from 'react';
import ReactDOM from 'react-dom';
import './App.css';

class ChatPeople extends React.Component {
    constructor(props) {
        super(props);
        //     people[{
        //         username:"user1",
        //         img: "http://i.imgur.com/Tj5DGiO.jpg",
        //         chats:[]
        //     },
        //     {
        //         username:"user2",
        //         img: "http://i.imgur.com/Tj5DGiO.jpg",
        //         chats:[]
        //     }
        // ]
    }
    render(){
        return(
            <div className="chatpeople">
                 <h1>People</h1>
                 <ul>
                     <li>1</li>
                     <li>2</li>
                     <li>3</li>
                 </ul>
            </div>
           
        )
    }
}

export default ChatPeople;