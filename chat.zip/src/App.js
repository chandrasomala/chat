const express = require('express');
const mongoose = require('mongoose');
const user  = require('./routes/api/users')

const app = express();

//getting URL
const db = require('./config/keys').mongoURI
console.log(db)
//connect to mongoose
mongoose.connect(db).then(()=>{console.log("Mongodb connected")})
.catch(err => {console.log(err)})


app.get('/',(req,res)=>res.send("This is get route for test"));


//use routes
app.use('/api/users',user);
 
const port  = process.env.PORT || 5000;


app.listen(port,()=> console.log("Sever running on port "+port));