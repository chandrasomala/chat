// const mongoose = require('mongoose');

// // Chat Schema
// const Chat = mongoose.Schema({
//     roomTitle: {
//         type: String,
//         required: true
//     },
//     createdBy: {
//         type: String,
//         required: true
//     }
// });

// module.exports = mongoose.model('Chat', Chat);