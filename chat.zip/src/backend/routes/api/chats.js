const express = require('express');
const router = express.Router();
const http = require('http').Server(express);
const config = require('../../config/keys');
const Chat = require('../../model/chat');

router.get('/chats', (req, res, next) => {
    res.json({msg:"Backed end created"})
});