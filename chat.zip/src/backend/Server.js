const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const config = require('./config/keys');
const cors = require('cors');

// get config of database
mongoose.connect(config.database);

// on connect database
mongoose.connection.on('connected', () => {
    console.log('mongoose connected as:' + config.database);
});

// on reject database
mongoose.connection.on('error', (err) => {
    console.log('database Rejected ...' + err);
});

// initialization app variable with express
const app = express();
const http = require('http').Server(app);


// chats api routes
const chats = require('./routes/api/chats');

// Port Number
const port = 5000;

// CORS Middleware
app.use(cors());

// using chats routes as localhost:portnumber/chats/nextpath.
app.use('/chats', chats);

// index route
app.get('/', (req, res) => {
    res.send("This is get route for test");
});

// start server here
http.listen(port, () => {
    console.log('SERVER started on port number: '+port);
});














// //getting URL
// const db = require('./config/keys').mongoURI
// console.log(db)
// //connect to mongoose
// mongoose.connect(db).then(()=>{console.log("Mongodb connected")})
// .catch(err => {console.log(err)})


// app.get('/',(req,res)=>res.send("This is get route for test"));


// //use routes
// //app.use('/api/users',user);

 
// const port  = process.env.PORT || 5000;


// app.listen(port,()=> console.log("Sever running on port "+port));